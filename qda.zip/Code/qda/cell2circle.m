%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function [normCell,qData] = cell2circle(cellIm,qData,normRadius,cellInfo,orientation)


cellCentroid = cellInfo.Centroid; 




[x,y] = meshgrid(1:size(cellIm,2),1:size(cellIm,1));

theta = atan2(y-cellCentroid(2),x-cellCentroid(1)); % units in radians

[u,v] = pol2cart(theta(:),normRadius(:));

u = double(round(u));
v = double(round(v));



val = max([max(abs(u)), min(abs(u)), max(abs(v)), min(abs(v)) ]);


[X,Y] = meshgrid(-val:val);
R = sqrt(X.^2 + Y.^2);


warning('off','MATLAB:TriScatteredInterp:DupPtsAvValuesWarnId') %Suppress warnings
warning('off','MATLAB:griddata:DuplicateDataPoints')
normCell = griddata(u,v,double(cellIm(:)),X,Y,'linear');
normCell(isnan(normCell))=0; % Remove NaNs
warning('on','MATLAB:TriScatteredInterp:DupPtsAvValuesWarnId') % Restore warnings
warning('on','MATLAB:griddata:DuplicateDataPoints')




if strcmp(orientation,'none')
else
    if strcmp(orientation,'cpa')
        angle = cellInfo.Orientation;
    else
        angle = orientation;
    end
    angleMap = orientMap(size(normCell),[(val+1), (val+1)],angle);
    indxOrientA = (angleMap==1);
    indxOrientB = (angleMap==-1);
    indxOrientNormA = (angleMap==2);
    indxOrientNormB = (angleMap==-2);
end



% RMI
qData.RMI.normMap = zeros(size(R));
prevLimit = -1;
for ii=1:length(qData.RMI.normR)
    limit = qData.RMI.normR(ii);
    indx = ((R>prevLimit)&(R<=limit));
    if strcmp(orientation,'none')
        qData.RMI.normMap(indx) = qData.RMI.data(ii);
    else
        qData.RMI.normMap(indx & indxOrientA) = qData.RMI.data.orientA(ii);
        qData.RMI.normMap(indx & indxOrientB) = qData.RMI.data.orientA(ii);
        qData.RMI.normMap(indx & indxOrientNormA) = qData.RMI.data.orientNormA(ii);
        qData.RMI.normMap(indx & indxOrientNormB) = qData.RMI.data.orientNormB(ii);
    end
    prevLimit = limit;
    clear indx limit
end
% LRMI
qData.LRMI.normMap = zeros(size(R));
prevLimit = -1;
for ii=1:length(qData.LRMI.normR)
    limit = qData.LRMI.normR(ii);
    indx = ((R>prevLimit)&(R<=limit));
    if strcmp(orientation,'none')
        qData.LRMI.normMap(indx) = qData.LRMI.data(ii);
    else
        qData.LRMI.normMap(indx & indxOrientA) = qData.LRMI.data.orientA(ii);
        qData.LRMI.normMap(indx & indxOrientB) = qData.LRMI.data.orientA(ii);
        qData.LRMI.normMap(indx & indxOrientNormA) = qData.LRMI.data.orientNormA(ii);
        qData.LRMI.normMap(indx & indxOrientNormB) = qData.LRMI.data.orientNormB(ii);
    end
    prevLimit = limit;
    clear indx limit
end
% CARIP
qData.CARIP.normMap = zeros(size(R));
prevLimit = -1;
for ii=1:length(qData.CARIP.normR)
    limit = qData.CARIP.normR(ii);
    indx = ((R>prevLimit)&(R<=limit));
    if strcmp(orientation,'none')
        qData.CARIP.normMap(indx) = qData.CARIP.data(ii);
    else
        qData.CARIP.normMap(indx & indxOrientA) = qData.CARIP.data.orientA(ii);
        qData.CARIP.normMap(indx & indxOrientB) = qData.CARIP.data.orientA(ii);
        qData.CARIP.normMap(indx & indxOrientNormA) = qData.CARIP.data.orientNormA(ii);
        qData.CARIP.normMap(indx & indxOrientNormB) = qData.CARIP.data.orientNormB(ii);
    end
    prevLimit = limit;
    clear indx limit
end




