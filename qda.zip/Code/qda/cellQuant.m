%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function qData = cellQuant(segCell,normRadius,options)


maxRadius = options.maxRadius;
ringNum = options.ringNum;
qMetric = options.qMetric ;
divisionType = options.divisionType;
mbFilter = options.movingBoxFilter;
if mbFilter
    mbFilterSize = options.movingBoxFilterSize;
    mbFilterType = options.movingBoxFilterType;
end
cellInfo = options.cellInfo;

% Main calculations
qData.map = zeros(size(segCell));
qData.normR = zeros(ringNum,1);
qData.normRMap = zeros(size(segCell));
if strcmp(options.orientation,'none')
    qData.data = zeros(ringNum,1);
else
    qData.data.orientA = zeros(ringNum,1);
    qData.data.orientB = zeros(ringNum,1);
    qData.data.orientNormA = zeros(ringNum,1);
    qData.data.orientNormB = zeros(ringNum,1);
    if strcmp(options.orientation,'cpa')
        angle = cellInfo.Orientation;
    else
        angle = options.orientation;
    end
    angleMap = orientMap(size(segCell),cellInfo.Centroid,angle);
    indxOrientA = (angleMap==1);
    indxOrientB = (angleMap==-1);
    indxOrientNormA = (angleMap==2);
    indxOrientNormB = (angleMap==-2);
end


prevLimit = -1;
for ii=1:ringNum
    switch divisionType
        case 'R'
            limit = ii*(maxRadius/ringNum);
        case 'A'
            limit = sqrt(ii)*(maxRadius/sqrt(ringNum));
    end
    qData.normR(ii) = limit;
    indx = ((normRadius>prevLimit)&(normRadius<=limit));
    if strcmp(options.orientation,'none')
        switch qMetric
            case 'mean'
                qData.data(ii) = mean(segCell(indx));
            case 'max'
                qData.data(ii) = max(segCell(indx));
            case 'min'
                qData.data(ii) = min(segCell(indx));
            case 'median'
                qData.data(ii) = median(segCell(indx));
            case 'intPercent'
                qData.data(ii) = 100*(sum(segCell(indx))/sum(segCell(:)));
        end
        qData.map(indx) = qData.data(ii);
    else
        switch qMetric
            case 'mean'
                qData.data.orientA(ii) = mean(segCell(indx & indxOrientA));
                qData.data.orientB(ii) = mean(segCell(indx & indxOrientB));
                qData.data.orientNormA(ii) = mean(segCell(indx & indxOrientNormA));
                qData.data.orientNormB(ii) = mean(segCell(indx & indxOrientNormB));
            case 'max'
                qData.data.orientA(ii) = max(segCell(indx & indxOrientA));
                qData.data.orientB(ii) = max(segCell(indx & indxOrientB));
                qData.data.orientNormA(ii) = max(segCell(indx & indxOrientNormA));
                qData.data.orientNormB(ii) = max(segCell(indx & indxOrientNormB));
            case 'min'
                qData.data.orientA(ii) = min(segCell(indx & indxOrientA));
                qData.data.orientB(ii) = min(segCell(indx & indxOrientB));
                qData.data.orientNormA(ii) = min(segCell(indx & indxOrientNormA));
                qData.data.orientNormB(ii) = min(segCell(indx & indxOrientNormB));
            case 'median'
                qData.data.orientA(ii) = median(segCell(indx & indxOrientA));
                qData.data.orientB(ii) = median(segCell(indx & indxOrientB));
                qData.data.orientNormA(ii) = median(segCell(indx & indxOrientNormA));
                qData.data.orientNormB(ii) = median(segCell(indx & indxOrientNormB));
            case 'intPercent'
                qData.data.orientA(ii) = 100*(sum(segCell(indx & indxOrientA))/sum(segCell(:))); 
                qData.data.orientB(ii) = 100*(sum(segCell(indx & indxOrientB))/sum(segCell(:))); 
                qData.data.orientNormA(ii) = 100*(sum(segCell(indx & indxOrientNormA))/sum(segCell(:))); 
                qData.data.orientNormB(ii) = 100*(sum(segCell(indx & indxOrientNormB))/sum(segCell(:))); 
        end
        qData.map(indx & indxOrientA) = qData.data.orientA(ii) ;
        qData.map(indx & indxOrientB) = qData.data.orientB(ii) ;
        qData.map(indx & indxOrientNormA) = qData.data.orientNormA(ii) ;
        qData.map(indx & indxOrientNormB) = qData.data.orientNormB(ii) ;              
    end
    qData.normRMap(indx) = ii;
    prevLimit = limit;
    clear indx limit
end



% Clean the final output with a moving-box filter   -------- It is an optional step
if mbFilter
    if strcmp(options.orientation,'none')
        qData.filtData = slidingFilt(qData.data,mbFilterSize,mbFilterType);
    else
        qData.filtData.orientA = slidingFilt(qData.data.orientA,mbFilterSize,mbFilterType);
        qData.filtData.orientB = slidingFilt(qData.data.orientB,mbFilterSize,mbFilterType);
        qData.filtData.orientNormA = slidingFilt(qData.data.orientNormA,mbFilterSize,mbFilterType);
        qData.filtData.orientNormB = slidingFilt(qData.data.orientNormB,mbFilterSize,mbFilterType);
    end
end



