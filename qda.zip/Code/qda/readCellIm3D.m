%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function [im2D, im3D] = readCellIm3D(fileName,zProjection,zRange)




% read the Zstack

InfoImage=imfinfo(fileName);
mImage=InfoImage(1).Width;
nImage=InfoImage(1).Height;
NumberImages=length(InfoImage);
im3D=zeros(nImage,mImage,NumberImages,'uint16');

TifLink = Tiff(fileName, 'r');
for ii=1:NumberImages
    TifLink.setDirectory(ii);
    im3D(:,:,ii)=TifLink.read();
end
TifLink.close();
clear  InfoImage NumberImages TifLink mImage nImage ii


switch zProjection
    case 'max'
        if strcmp(zRange,'full')
            im2D = max(im3D,[],3);
        else
            im2D = max(im3D(:,:,zRange(1):zRange(2)),[],3);
        end
    case 'mean'
        if strcmp(zRange,'full')
            im2D = mean(im3D,3);
        else
            im2D = mean(im3D(:,:,zRange(1):zRange(2)),3);
        end
end

