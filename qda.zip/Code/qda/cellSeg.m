%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function [segCell,cellMask,segCell3D] = cellSeg(I,options,I3D)


if options.externalCellMask
   
    mask = imread(options.cellMaskImage);
    mask = cast(mask,'like',I); % Binary segmentation
    
else
    
    
    
    if options.semiautomatic % it requires dipImage Library
        
        
        th = threshold(dip_image(I),'isodata',3)>0;
        % Show the initial mask and ask the user to separate the cell under
        % study from the rest of the cells
        figure
        BW = roipoly(boolean(th));
        close all
        initialMask = dip_image(BW)*th; clear BW
        % Remove spurious small segmented objects
        lb = label(initialMask);
        sizeInfo = measure(lb,[],'size');
        [~,indx] = max(sizeInfo.size);
        mask = fillholes(lb==indx);
        % Convert the data to the right type
        mask = boolean(mask);
        % Save the mask image if required
        if options.saveCellMask
            imwrite(mask,[options.saveFileName '.png'])
        end
        
        mask = cast(mask,'like',I); % Binary segmentation
        
        
    else
        
        
        I2 = imadjust(I,stretchlim(I,[0 0.95]),[0 1]);
        
        % Manual segmentation of one cell
        BW = roipoly(I2);
        close all
        % Save the mask image if required
        if options.saveCellMask
            imwrite(BW,[options.saveFileName '.png'])
        end
        
        mask = cast(BW,'like',I); % Binary segmentation
        
        
    end
    
end





segTmp = mask.*I; % Grey Scale segmentation
% Crop original image dimmensions to fit segmented cell size
margin =10;
[row, col] = find(mask);
w_ini = max(min(row) - margin,1);
w_end = min(max(row) + margin,size(I,1));
h_ini = max(min(col) - margin,1);
h_end = min(max(col) + margin,size(I,2));

segCell = segTmp(w_ini:w_end,h_ini:h_end);
cellMask =  mask(w_ini:w_end,h_ini:h_end);



if nargin==3 % if a z-stack is provided
    mask3D = repmat(mask,[1 1 size(I3D,3)]);
    segTmp3D = mask3D.*I3D;
    segCell3D = segTmp3D(w_ini:w_end,h_ini:h_end,:);
end

