%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function angularMap = orientMap(imsize,centroid,angle)



[x,y] = meshgrid(1:imsize(2),1:imsize(1));


theta = -atan2(y-centroid(2),x-centroid(1)); % units in radians
theta =  mod(((180/pi)*theta) - angle,360) ;

angularMap = zeros(imsize);
angularMap((theta<=45)|(theta>315)) =1;
angularMap((theta>45)&(theta<=135)) =2;
angularMap((theta>135)&(theta<=225)) = -1;
angularMap((theta>225)&(theta<=315)) = -2;
