%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function qda(options)

%% Input Parameters
inputFileName = [options.filePath filesep options.fileName];
inputFileExtension = options.fileExtension;
outputFileName = [options.saveFolder filesep 'qdaResults_' options.fileName];

zStack = options.zStack;
zProjection = options.zProjection;
zRange = options.zRange;

intensityNormFactor = options.intensityNormFactor;

ringNum = options.ringNum;

maxRadius = options.maxRadius;

orientation = options.orientation;

movingBoxFilter = options.movingBoxFilter;

normCellPlot = options.normCellPlot;

showFigs = options.showFigs;


% Turn off some warnings during the execution
warning('off','MATLAB:scatteredInterpolant:DupPtsAvValuesWarnId')
warning('off','MATLAB:imagesci:tiffmexutils:libtiffErrorAsWarning')
warning('off','MATLAB:imagesci:tiffmexutils:libtiffWarning')



%%  Read Cell Image

if zStack
    [I,I3D] = readCellIm3D(char([inputFileName '.' inputFileExtension]),zProjection,zRange);
else
    I = imread(char([inputFileName '.' inputFileExtension]));
end


%% Cell Segmentation

% Select the input options for the segmentation
segOptions.cellMaskImage = options.externalCellMaskImage;
if segOptions.externalCellMask 
    segOptions.cellMaskImage = options.cellMaskImage;
else
    segOptions.semiautomatic = options.semiautomaticCellSeg;
end
segOptions.saveCellMask = options.saveCellMask;
if segOptions.saveCellMask
    segOptions.saveFileName = [options.saveFolder filesep 'cellMask_' options.fileName];;
end


% Perform the segmentation
if zStack
    [segCell,cellMask, segCell3D] = cellSeg(I,segOptions,I3D);
    clear I3D
else
    [segCell,cellMask] = cellSeg(I,segOptions);
end
clear I




%% Intensity normalization

segCell = 100*(double(segCell)/intensityNormFactor);
if zStack
    segCell3D = 100*(double(segCell3D)/intensityNormFactor);
end


%% Intensity percentage along Z axis -> Z Intensity Percentage (ZIP)

if zStack
    zip = 100*(squeeze(sum(sum(segCell3D,1),2))/sum(squeeze(sum(sum(segCell3D,1),2))));
    clear segCell3D
end

%% Normalization of the radius

[normRadius,cellInfo] = rNorm(cellMask,maxRadius);
normRadiusCell = normRadius.*cast(cellMask,'like',normRadius);

%% Quantification of the labeled structure inside the cell

options.cellInfo = cellInfo;
% RMI
options.qMetric = 'mean';
options.divisionType = 'R'; % Sectors with normalized radius of the same length
options.ringNum = 100;
qData.RMI = cellQuant(segCell,normRadius,options);
% LRMI
options.qMetric = 'mean';
options.divisionType = 'R'; % Sectors with normalized radius of the same length
options.ringNum = ringNum;
options.movingBoxFilter = false;
qData.LRMI = cellQuant(segCell,normRadius,options);
% CARIP
options.qMetric = 'intPercent'; % intensity percentage 
options.divisionType = 'A'; % Sectors with the same normalized area
options.ringNum = ringNum;
options.movingBoxFilter = false;
qData.CARIP = cellQuant(segCell,normRadius,options);
% ZIP
if zStack
    qData.zip = zip; 
end


%% Normalized cell Shape (optional)

if normCellPlot
    [normCell,qData] = cell2circle(segCell,qData,normRadius,cellInfo,orientation);
end

%% Plot results (optional)

if showFigs
    showFig(segCell,false,'stretch','Segmented Cell - 2D Projection')
    showFig(qData.RMI.normRMap,true,'stretch','Normalized Radius')
    showFig(qData.RMI.map,true,options.colormapScale.RMI,'RMI')
    showFig(qData.LRMI.map,true,options.colormapScale.LRMI,'LRMI')
    showFig(qData.CARIP.map,true,options.colormapScale.CARIP,'CARIP')
    plotRMI(qData.RMI,orientation,movingBoxFilter)
    if zStack
        figure
        plot(qData.zip)
        title('Z Intensity Percentage')
    end
        
    if normCellPlot
        showFig(normCell,false,'stretch','Normalized Shape - Segmented Cell - 2D Projection')
        showFig(qData.RMI.normMap,true,options.colormapScale.RMI,'Normalized Shape - RMI')
        showFig(qData.LRMI.normMap,true,options.colormapScale.LRMI,'Normalized Shape - LRMI')
        showFig(qData.CARIP.normMap,true,options.colormapScale.CARIP,'Normalized Shape - CARIP')
    end
end



%% Save useful data

% Save .mat files
save(char([outputFileName '.mat']),'segCell','cellMask','normRadius','normRadiusCell','qData') %matlab file
if normCellPlot
    save(char([outputFileName '.mat']),'segCell','cellMask','normRadius','normRadiusCell','qData','normCell') %matlab file
end


%%

% Turn back on some warnings
warning('on','MATLAB:scatteredInterpolant:DupPtsAvValuesWarnId')
warning('on','MATLAB:imagesci:tiffmexutils:libtiffErrorAsWarning')
warning('on','MATLAB:imagesci:tiffmexutils:libtiffWarning')