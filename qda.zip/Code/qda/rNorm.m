%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function [normRadius,cellInfo] = rNorm(cellMask,maxRadius)


% Cell centroid
cellInfo = regionprops(cellMask, 'Centroid','Orientation');
cellCentroid = cellInfo.Centroid; 
 

% Distance to/from the cell boundary
BdistIn = bwdist(not(cellMask)); % distance to the cell boundary --> inside
BdistOut = bwdist((cellMask)); % distance from the cell boundary --> outside

% Distance to centroid
[x,y] = meshgrid(1:size(cellMask,2),1:size(cellMask,1));
Cdist = sqrt((x-cellCentroid(1)).^2 + (y-cellCentroid(2)).^2);


% Normalized radius
cellMask = double(cellMask);
normRadiusIn = maxRadius*((cellMask.*Cdist)./( (BdistIn-1)+(cellMask.*Cdist)));
normRadiusOut = maxRadius*((BdistOut+(not(cellMask).*Cdist))./(not(cellMask).*Cdist));
% Combine info inside and outside the cell 
normRadiusIn(isnan(normRadiusIn))=0;
normRadiusOut(isnan(normRadiusOut))=0;
normRadius = normRadiusIn + normRadiusOut;

