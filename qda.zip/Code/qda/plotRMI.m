%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.


function plotRMI(RMI,orient,mbfilt)

if strcmp(orient,'none')
    
    figure
    plot(RMI.normR,RMI.data)
    if mbfilt
        hold on
        plot(RMI.normR,RMI.filtData,'r')
        title('RMI - raw and filtered data')
        hold off
    else
        title('RMI - raw')
    end
    
    
else
 
    figure
    plot(RMI.normR,RMI.data.orientA)
    if mbfilt
        hold on
        plot(RMI.normR,RMI.filtData.orientA,'r')
        title('RMI - Orientation A - raw and filtered data')
        hold off
    else
        title('RMI - raw')
    end
    
    figure
    plot(RMI.normR,RMI.data.orientB)
    if mbfilt
        hold on
        plot(RMI.normR,RMI.filtData.orientB,'r')
        title('RMI - Orientation B - raw and filtered data')
        hold off
    else
        title('RMI - raw')
    end
    
    figure
    plot(RMI.normR,RMI.data.orientNormA)
    if mbfilt
        hold on
        plot(RMI.normR,RMI.filtData.orientNormA,'r')
        title('RMI - Normal to orientation A - raw and filtered data')
        hold off
    else
        title('RMI - raw')
    end
    
    figure
    plot(RMI.normR,RMI.data.orientNormB)
    if mbfilt
        hold on
        plot(RMI.normR,RMI.filtData.orientNormB,'r')
        title('RMI - Normal to orientation B - raw and filtered data')
        hold off
    else
        title('RMI - raw')
    end
    
    
    
    
    
end