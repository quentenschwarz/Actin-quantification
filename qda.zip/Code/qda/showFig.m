%     This file is part of QDA.
%     Copyright (C) 2012 Ceit - University of Navarra
%     Copyright (C) 2014 KU Leuven
%     Copyright (C) 2012-2014 Alvaro Jorge-Penas (ajorge.es@gmail.com)
%
%     This library is free software: you can redistribute it and/or modify
%     it under the terms of the GNU Lesser General Public License as published
%     by the Free Software Foundation, either version 3 of the License, or
%     (at your option) any later version.
%
%     This software is provided "as is",
%     but WITHOUT ANY WARRANTY; without even the implied warranty of
%     MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%     GNU Lesser General Public License for more details
%     <http://www.gnu.org/licenses/>.

function showFig(data,jetMap,scale,figTitle)

figure

if jetMap
    if strcmp(scale,'stretch')
        imshow(data,[min(data(:)), max(data(:))])
    else
       imshow(data,[scale(1), scale(2)])
    end
    colormap(jet)
    colorbar
else
    imshow(data,[min(data(:)), max(data(:))])    
end

title(figTitle)