clear all
close all
clc


%% Input Parameters


installationPath = 'C:\Users\Alvaro\Desktop\qda\Code\qda';


inputOptions.filePath = 'C:\Users\Alvaro\Desktop\qda\inputImages';
inputOptions.fileName = 'test_Actin3D';
inputOptions.fileExtension = 'tif'; % for z-stacks only 'tif' format is supported
inputOptions.saveFolder = 'C:\Users\Alvaro\Desktop\qda\outputData';

inputOptions.zStack = true;
inputOptions.zProjection = 'max'; % projection to a 2D image if a z-stack is provided
% inputOptions.zProjection = 'max'; 
% inputOptions.zProjection = 'mean';
inputOptions.zRange = 'full'; % [initialZslice finalZslice] or 'full'


inputOptions.intensityNormFactor = 255; % typically ((2^bitdepth)-1);


inputOptions.maxRadius = 150;  % circle's maximun value for the normalized radius
inputOptions.ringNum = 5; % Number of concentric sectors where the metrics are calculated




inputOptions.externalCellMask = false; % True to import/read a precomputed segmented cell mask
inputOptions.externalCellMaskImage = 'C:\Users\Alvaro\Desktop\qda\outputData\cellMask_test_Actin2D.png'; % File name (with the path and extension) of the file containing the external cell mask
inputOptions.semiautomaticCellSeg = true; % If true, it requires the dipImage Library (http://www.diplib.org)
inputOptions.saveCellMask = true; % True to save the calculated cell mask to a png image in the specified saveFolder



inputOptions.orientation = 'none'; % angle in degrees respect to the X axis.
% inputOptions.orientation = 'none' % no preferred orientation
% inputOptions.orientation = 'cpa' % cell principal axis


inputOptions.movingBoxFilter = true;
inputOptions.movingBoxFilterSize = 7;
inputOptions.movingBoxFilterType = 'mean';
% movingBoxFilterType = 'mean'
% movingBoxFilterType = 'median'
% movingBoxFilterType = 'max'
% movingBoxFilterType = 'min'


inputOptions.normCellPlot = true; % Draw the cell and its metrics in the normalized shape

inputOptions.showFigs = true; % Show the results
inputOptions.colormapScale.RMI = 'stretch';%  it could also be a numerical vector with the desired range: [scaleMin scaleMax]
inputOptions.colormapScale.LRMI = 'stretch';%  it could also be a numerical vector with the desired range: [scaleMin scaleMax]
inputOptions.colormapScale.CARIP = 'stretch';% it could also be a numerical vector with the desired range: [scaleMin scaleMax]













%%  DO NOT MODIFY THE FOLLOWING CODE

tic
addpath(genpath(installationPath))
qda(inputOptions)
rmpath(genpath(installationPath))
toc